package com.apress.kubdev.news.feeds;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeFeedsControllerIT extends FeedsControllerTest{

}
