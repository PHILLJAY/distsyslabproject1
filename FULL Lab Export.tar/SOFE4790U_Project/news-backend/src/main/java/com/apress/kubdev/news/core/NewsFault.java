package com.apress.kubdev.news.core;

public enum NewsFault {
	UNKNOWN, ANALYSIS_ERROR, DUPLICATE
}
