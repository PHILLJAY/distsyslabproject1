package com.apress.kubdev.news.geonames;

public class GeonameResult {

}
